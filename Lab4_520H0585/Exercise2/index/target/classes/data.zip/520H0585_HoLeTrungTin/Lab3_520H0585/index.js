const express = require('express')
const bodyParser = require('body-parser')
const emailvalidator = require('email-validator')
const multer = require('multer')

const app = express()
const upload = multer({
    dest: 'uploads',
    fileFilter: (req, file, callback) => {
        if(file.mimetype.startsWith('image/')) callback(null, true)
        else callback(null, false)
    },
    limits: {
        fileSize: 100000 // max = 100kb
    },
})

app.set('view engine', 'ejs')
app.use(bodyParser.urlencoded({extended: false}))

app.get('/', (req, res) => {
    res.render('index')
})

app.get('/add', (req, res) => {
    res.render('add', {
        error: '', 
        name: '', 
        price: '', 
        desc: '',
    })
})

app.post('/add', (req, res) => {
    let uploader = upload.single('image')

    uploader(req, res, err => {
        let {name, price, desc} = req.body

        res.set('Content-Type', 'text/html')

        let error = undefined
        if(!name || name.length === 0){
            error = 'Vui lòng nhập tên sản phẩm'
        }
        else if(!price || price.length === 0){
            error = 'Vui lòng nhập giá sản phẩm'
        }
        else if(isNaN(price) || parseInt(price) < 0){
            error = 'Vui lòng nhập giá hợp lệ'
        }
        if(!desc || desc.length === 0){
            error = 'Vui lòng nhập mô tả sản phẩm'
        }
        else if (err){
            error = 'Dung lượng ảnh quá to, cần ảnh từ 10kB trở xuống'
        }
        else if(!req.file) {
            error = 'Không phải ảnh hoặc chưa có ảnh'
        } 
        
        if(error){
            res.render('add', {error, name, price, desc})
        }
        else return res.end('Thêm sản phẩm thành công')
    }) 
})

app.get('/login', (req, res)=> {
    res.render('login', {
        email: '',
        password: '',
    })
})

app.post('/login', async (req, res) => {
    let acc = req.body
    let error = ''
    if(!acc.email){
        error = 'Vui lòng nhập email'
    } 
    else if(!acc.password){
        error = 'Vui lòng nhập mật khẩu'
    } 
    else if(!emailvalidator.validate(acc.email)){
        error = 'Vui lòng nhập đúng định dạng email'
    }
    else if(acc.password.length < 6){
        error = 'Mật khẩu cần có từ 6 kí tự trở lên'
    }
    else if(acc.email !== 'admin@gmail.com' || acc.password !== '123456') {
        error = 'Sai email hoặc mật khẩu'
    }
    
    if (error.length === 0) {
        res.set('Content-Type', 'text/html')
        return res.end('Đăng nhập thành công')
    }
    else res.render('login', {
        errorMessage: error,
        email: acc.email,
        password: acc.password
    })
})

app.use((req, res)=> {
    res.send('Page not found')
})

app.listen(8080, () => console.log("Server is running!"))